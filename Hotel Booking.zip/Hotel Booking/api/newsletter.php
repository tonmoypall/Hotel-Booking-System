<?php
require_once dirname(__DIR__).'/config/config.php';
$email=strtolower(trim($_POST['email']??''));
if(!filter_var($email,FILTER_VALIDATE_EMAIL))json_response(['success'=>false,'message'=>'Please enter a valid email address.'],422);
try{$stmt=getDB()->prepare("INSERT INTO newsletter_subscribers(email) VALUES(?)");$stmt->execute([$email]);json_response(['success'=>true,'message'=>'You are subscribed successfully.']);}
catch(PDOException $e){json_response(['success'=>false,'message'=>'This email is already subscribed.'],409);}
