<?php
require_once dirname(__DIR__).'/config/config.php';
require_login();
$id=(int)($_POST['booking_id']??0);$pdo=getDB();
try{$pdo->beginTransaction();$stmt=$pdo->prepare("SELECT id,status FROM bookings WHERE id=? AND user_id=? FOR UPDATE");$stmt->execute([$id,$_SESSION['user_id']]);$b=$stmt->fetch();if(!$b)throw new Exception('Booking not found.');
if(!in_array($b['status'],['Pending','Confirmed']))throw new Exception('This booking cannot be cancelled.');
$pdo->prepare("UPDATE bookings SET status='Cancelled',payment_status=CASE WHEN payment_status='Paid' THEN 'Refunded' ELSE payment_status END WHERE id=?")->execute([$id]);$pdo->commit();json_response(['success'=>true,'message'=>'Booking cancelled successfully.']);}catch(Exception $e){if($pdo->inTransaction())$pdo->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],422);}
