<?php
require_once dirname(__DIR__).'/config/config.php';
require_login();$hotel=(int)($_POST['hotel_id']??0);$pdo=getDB();
$check=$pdo->prepare("SELECT id FROM wishlists WHERE user_id=? AND hotel_id=?");$check->execute([$_SESSION['user_id'],$hotel]);if($check->fetch()){ $pdo->prepare("DELETE FROM wishlists WHERE user_id=? AND hotel_id=?")->execute([$_SESSION['user_id'],$hotel]);json_response(['success'=>true,'saved'=>false]);}
$pdo->prepare("INSERT INTO wishlists(user_id,hotel_id) VALUES(?,?)")->execute([$_SESSION['user_id'],$hotel]);json_response(['success'=>true,'saved'=>true]);
