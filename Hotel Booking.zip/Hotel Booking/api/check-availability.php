<?php
require_once dirname(__DIR__).'/config/config.php';
$roomId=(int)($_GET['room_id']??0);$cin=$_GET['checkin']??'';$cout=$_GET['checkout']??'';$qty=(int)($_GET['rooms']??1);
if($roomId<1||$cin<$cout||$cin<date('Y-m-d'))json_response(['success'=>false,'message'=>'Invalid availability request'],422);
$pdo=getDB();$r=$pdo->prepare("SELECT total_quantity FROM rooms WHERE id=?");$r->execute([$roomId]);$total=(int)$r->fetchColumn();
$b=$pdo->prepare("SELECT COALESCE(SUM(br.quantity),0) FROM bookings b JOIN booking_rooms br ON br.booking_id=b.id WHERE br.room_id=? AND b.status NOT IN ('Cancelled','Completed') AND NOT (b.checkout<=? OR b.checkin>=?)");$b->execute([$roomId,$cin,$cout]);$available=$total-(int)$b->fetchColumn();
json_response(['success'=>true,'available'=>max(0,$available),'can_book'=>$available>=$qty]);
