<?php
$pageTitle='Sign in | Aurelia';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/navbar.php';
$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()){$error='Invalid security token.';}else{$email=strtolower(trim($_POST['email']??''));$pass=$_POST['password']??'';$stmt=getDB()->prepare("SELECT * FROM users WHERE email=? AND is_active=1");$stmt->execute([$email]);$user=$stmt->fetch();
 if($user&&password_verify($pass,$user['password_hash'])){$_SESSION['user_id']=$user['id'];$_SESSION['user_name']=$user['full_name'];$_SESSION['role']=$user['role'];session_regenerate_id(true);redirect($user['role']==='admin'?'admin/index.php':'dashboard/');}else{$error='Email or password is incorrect.';}
}}
?>
<main class="auth-page"><div class="container"><div class="auth-card"><p class="eyebrow">WELCOME BACK</p><h1>Sign in</h1><?php if($error):?><div class="alert alert-danger mt-3"><?= e($error) ?></div><?php endif;?><form method="post" class="mt-4"><?= csrf_field()?><label class="form-label">Email</label><input class="form-control mb-3" type="email" name="email" required><label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" required><div class="d-flex justify-content-between mb-3"><div class="form-check"><input class="form-check-input" type="checkbox" name="remember" id="remember"><label class="form-check-label" for="remember">Remember me</label></div><a href="<?= e(BASE_URL) ?>/forgot-password.php">Forgot password?</a></div><button class="btn btn-gold w-100">Sign in</button></form><p class="text-center mt-3">New here? <a href="<?= e(BASE_URL) ?>/register.php">Create an account</a></p></div></div></main>
<?php require_once __DIR__.'/includes/footer.php'; ?><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
