document.addEventListener('DOMContentLoaded',()=>{
 const newsletter=document.querySelector('#newsletterForm');
 if(newsletter)newsletter.addEventListener('submit',async e=>{
  e.preventDefault();const fd=new FormData(newsletter);
  const res=await fetch(document.querySelector('script[src*="/assets/js/main.js"]')?.src.replace(/assets\/js\/main\.js.*$/,'api/newsletter.php')||'api/newsletter.php',{method:'POST',body:fd});
  const data=await res.json().catch(()=>({success:false,message:'Unable to subscribe.'}));
  alert(data.message);
 });
 document.querySelectorAll('input[type="date"]').forEach(input=>{
  if(!input.value&&input.name==='checkin')input.value=new Date(Date.now()+86400000).toISOString().slice(0,10);
 });
});
