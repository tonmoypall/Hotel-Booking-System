document.addEventListener('DOMContentLoaded',()=>{
 const cin=document.querySelector('#checkin'),cout=document.querySelector('#checkout');
 if(cin&&cout){const validate=()=>{if(cout.value&&cin.value&&cout.value<=cin.value){cout.setCustomValidity('Check-out must be after check-in.')}else cout.setCustomValidity('')};cin.addEventListener('change',validate);cout.addEventListener('change',validate);validate();}
});
