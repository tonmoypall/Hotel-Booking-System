# Installation

## Requirements
- XAMPP with Apache, MySQL and PHP 8+

## Setup
1. The project is in `C:\xampp\htdocs\Hotel Booking`.
2. Start Apache and MySQL.
3. Open phpMyAdmin and import `database/schema.sql`.
4. Default database settings are:
   - Host: `127.0.0.1`
   - Database: `hotel_booking_db`
   - User: `root`
   - Password: empty
5. Open `http://localhost/Hotel%20Booking/`.

## Demo accounts
- Administrator: `admin@aurelia.test`
- Password: `password`
- Customer: `samantha@example.com`
- Password: `password`

The administrator login redirects to `/admin/`.
