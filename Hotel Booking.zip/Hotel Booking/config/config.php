<?php
declare(strict_types=1);
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>isset($_SERVER['HTTPS'])]);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$projectRoot = str_replace('\\', '/', dirname(__DIR__));
$documentRoot = str_replace('\\', '/', $_SERVER['DOCUMENT_ROOT'] ?? '');
$basePath = substr($projectRoot, strlen(rtrim($documentRoot, '/')));
define('BASE_URL', rtrim($basePath, '/') ?: '');
define('APP_NAME', 'Aurelia Hotels');
define('CURRENCY', 'USD');

require_once __DIR__ . '/database.php';
require_once dirname(__DIR__) . '/includes/functions.php';
