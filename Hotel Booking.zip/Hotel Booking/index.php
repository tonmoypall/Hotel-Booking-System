<?php
$pageTitle='Aurelia Hotels | Exceptional Stays';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/navbar.php';
$pdo=getDB();
$hotels=$pdo->query("SELECT h.*, d.name destination, d.country, (SELECT image FROM hotel_images WHERE hotel_id=h.id LIMIT 1) image,
(SELECT MIN(price_per_night) FROM rooms WHERE hotel_id=h.id AND status='active') price,
(SELECT ROUND(AVG(rating),1) FROM reviews WHERE hotel_id=h.id AND status='approved') rating
FROM hotels h JOIN destinations d ON d.id=h.destination_id WHERE h.status='active' AND h.featured=1 LIMIT 6")->fetchAll();
$destinations=$pdo->query("SELECT d.*, (SELECT COUNT(*) FROM hotels h WHERE h.destination_id=d.id AND h.status='active') hotel_count FROM destinations d WHERE d.is_active=1")->fetchAll();
$offers=$pdo->query("SELECT * FROM offers WHERE is_active=1 AND valid_until>=CURDATE() LIMIT 3")->fetchAll();
?>
<main>
  <section class="hero">
    <div class="hero-overlay"></div>
    <div class="container hero-content">
      <p class="eyebrow">CURATED LUXURY ESCAPES</p>
      <h1>Find Your Perfect Stay</h1>
      <p class="hero-subtitle">Discover exceptional hotels and unforgettable experiences.</p>
      <form class="search-box" action="<?= e(BASE_URL) ?>/hotels.php" method="get">
        <div class="search-field"><label>Destination</label><div><i class="bi bi-geo-alt"></i><input name="destination" placeholder="Where are you going?" value="<?= e($_GET['destination']??'') ?>"></div></div>
        <div class="search-field"><label>Check in</label><div><i class="bi bi-calendar3"></i><input type="date" name="checkin" value="<?= e($_GET['checkin']??date('Y-m-d',strtotime('+1 day'))) ?>"></div></div>
        <div class="search-field"><label>Check out</label><div><i class="bi bi-calendar3"></i><input type="date" name="checkout" value="<?= e($_GET['checkout']??date('Y-m-d',strtotime('+3 days'))) ?>"></div></div>
        <div class="search-field"><label>Guests</label><div><i class="bi bi-person"></i><select name="guests"><option>1</option><option selected>2</option><option>3</option><option>4</option><option>5</option></select></div></div>
        <button class="search-btn" type="submit"><i class="bi bi-search"></i><span>Search</span></button>
      </form>
    </div>
  </section>
  <section class="section">
    <div class="container">
      <div class="section-heading"><div><p class="eyebrow">HANDPICKED FOR YOU</p><h2>Featured Hotels</h2></div><a href="<?= e(BASE_URL) ?>/hotels.php" class="text-link">View all hotels <i class="bi bi-arrow-right"></i></a></div>
      <div class="row g-4">
        <?php foreach($hotels as $h): ?>
        <div class="col-md-6 col-lg-4">
          <article class="hotel-card">
            <div class="hotel-image"><img src="<?= e(BASE_URL.'/'.$h['image']) ?>" alt="<?= e($h['name']) ?>" loading="lazy"><span class="rating-badge"><i class="bi bi-star-fill"></i> <?= $h['rating']?$h['rating']:'New' ?></span></div>
            <div class="hotel-card-body"><p class="location"><i class="bi bi-geo-alt"></i> <?= e($h['destination'].', '.$h['country']) ?></p><h3><a href="<?= e(BASE_URL) ?>/hotel-details.php?slug=<?= urlencode($h['slug']) ?>"><?= e($h['name']) ?></a></h3><div class="stars"><?= str_repeat('<i class="bi bi-star-fill"></i>',(int)$h['star_rating']) ?></div><div class="hotel-card-foot"><div><small>From</small><strong><?= money($h['price']) ?></strong><small>/ night</small></div><a class="btn btn-outline-navy" href="<?= e(BASE_URL) ?>/hotel-details.php?slug=<?= urlencode($h['slug']) ?>">View details</a></div></div>
          </article>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </section>
  <section class="section destinations-section" id="destinations">
    <div class="container"><div class="section-heading"><div><p class="eyebrow">EXPLORE BANGLADESH</p><h2>Popular Destinations</h2></div></div><div class="destination-grid">
      <?php foreach($destinations as $d): ?><a class="destination-card" href="<?= e(BASE_URL) ?>/hotels.php?destination=<?= urlencode($d['name']) ?>"><img src="<?= e(BASE_URL.'/'.$d['image']) ?>" alt="<?= e($d['name']) ?>" loading="lazy"><div><h3><?= e($d['name']) ?></h3><p><?= (int)$d['hotel_count'] ?> hotels</p></div></a><?php endforeach; ?>
    </div></div>
  </section>
  <?php if($offers): ?><section class="section"><div class="container"><div class="section-heading"><div><p class="eyebrow">LIMITED-TIME VALUE</p><h2>Special Offers</h2></div></div><div class="row g-4"><?php foreach($offers as $o): ?><div class="col-md-6"><article class="offer-card"><div><p>Exclusive offer</p><h3><?= e($o['title']) ?></h3><p><?= e($o['description']) ?></p><strong>Save <?= (int)$o['discount_percent'] ?>%</strong></div><a href="<?= e(BASE_URL) ?>/hotels.php" class="btn btn-light">Explore deal</a></article></div><?php endforeach; ?></div></div></section><?php endif; ?>
  <section class="section why-section"><div class="container"><div class="text-center section-heading centered"><div><p class="eyebrow">THE AURELIA PROMISE</p><h2>Why travel with us</h2></div></div><div class="row g-4"><?php $why=[['bi-tag','Best Price Guarantee','Competitive rates and no hidden surprises.'],['bi-shield-check','Secure Booking','Your reservation and personal data stay protected.'],['bi-headset','24/7 Support','Our travel specialists are always within reach.'],['bi-arrow-repeat','Easy Cancellation','Flexible options for more confident planning.']]; foreach($why as $w): ?><div class="col-6 col-lg-3"><div class="benefit"><i class="bi <?= $w[0] ?>"></i><h3><?= $w[1] ?></h3><p><?= $w[2] ?></p></div></div><?php endforeach; ?></div></div></section>
  <section class="newsletter"><div class="container"><div><p class="eyebrow">A WORLD OF EXCLUSIVE OFFERS</p><h2>Discover stories worth traveling for</h2></div><form id="newsletterForm"><input type="email" name="email" required placeholder="Your email address"><button class="btn btn-gold" type="submit">Subscribe</button></form></div></section>
</main>
<?php require_once __DIR__.'/includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(BASE_URL) ?>/assets/js/main.js"></script>
</body></html>
