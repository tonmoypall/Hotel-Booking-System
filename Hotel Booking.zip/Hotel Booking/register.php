<?php
$pageTitle='Create account | Aurelia';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/navbar.php';
$pdo=getDB();$error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!verify_csrf()){$error='Invalid security token.';}
 else{$name=trim($_POST['full_name']??'');$email=strtolower(trim($_POST['email']??''));$phone=trim($_POST['phone']??'');$pass=$_POST['password']??'';$confirm=$_POST['confirm_password']??'';
 if(strlen($name)<2||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($phone)<6||strlen($pass)<8||$pass!==$confirm)$error='Please provide valid details and matching passwords (8+ characters).';
 else{$s=$pdo->prepare("SELECT id FROM users WHERE email=?");$s->execute([$email]);if($s->fetch())$error='An account with this email already exists.';else{$pdo->prepare("INSERT INTO users(full_name,email,phone,password_hash) VALUES(?,?,?,?)")->execute([$name,$email,$phone,password_hash($pass,PASSWORD_DEFAULT)]);$_SESSION['user_id']=$pdo->lastInsertId();$_SESSION['user_name']=$name;$_SESSION['role']='customer';session_regenerate_id(true);redirect('dashboard/');}}}
}
?>
<main class="auth-page"><div class="container"><div class="auth-card"><p class="eyebrow">JOIN AURELIA</p><h1>Create your account</h1><?php if($error):?><div class="alert alert-danger mt-3"><?= e($error) ?></div><?php endif;?><form method="post" class="mt-4"><?= csrf_field()?><label class="form-label">Full name</label><input class="form-control mb-3" name="full_name" required value="<?= e($_POST['full_name']??'') ?>"><label class="form-label">Email</label><input class="form-control mb-3" type="email" name="email" required value="<?= e($_POST['email']??'') ?>"><label class="form-label">Phone</label><input class="form-control mb-3" name="phone" required value="<?= e($_POST['phone']??'') ?>"><label class="form-label">Password</label><input class="form-control mb-3" type="password" name="password" minlength="8" required><label class="form-label">Confirm password</label><input class="form-control mb-3" type="password" name="confirm_password" minlength="8" required><button class="btn btn-gold w-100 mt-2">Create account</button></form><p class="text-center mt-3">Already have an account? <a href="<?= e(BASE_URL) ?>/login.php">Sign in</a></p></div></div></main>
<?php require_once __DIR__.'/includes/footer.php'; ?><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
