CREATE DATABASE IF NOT EXISTS hotel_booking_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE hotel_booking_db;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS newsletter_subscribers, contact_messages, offer_hotels, offers, wishlists, reviews, payments, booking_rooms, bookings, room_facilities, room_images, rooms, hotel_facilities, hotel_images, hotels, destinations, facilities, settings, admins, users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, full_name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL UNIQUE,
 phone VARCHAR(30), password_hash VARCHAR(255) NOT NULL, role ENUM('customer','admin','manager') DEFAULT 'customer',
 profile_image VARCHAR(255), is_active TINYINT(1) DEFAULT 1, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE admins (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, force_password_change TINYINT(1) DEFAULT 1,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE destinations (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, country VARCHAR(100) NOT NULL, image VARCHAR(255), is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE facilities (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL UNIQUE, icon VARCHAR(80) DEFAULT 'bi-check-circle'
) ENGINE=InnoDB;
CREATE TABLE hotels (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, destination_id INT UNSIGNED NOT NULL, name VARCHAR(160) NOT NULL, slug VARCHAR(180) NOT NULL UNIQUE,
 address VARCHAR(255), description TEXT, star_rating TINYINT UNSIGNED DEFAULT 4, featured TINYINT(1) DEFAULT 0, status ENUM('active','inactive') DEFAULT 'active',
 cancellation_policy TEXT, checkin_time VARCHAR(20) DEFAULT '15:00', checkout_time VARCHAR(20) DEFAULT '11:00', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE hotel_images (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hotel_id INT UNSIGNED NOT NULL, image VARCHAR(255) NOT NULL,
 FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE hotel_facilities (hotel_id INT UNSIGNED NOT NULL, facility_id INT UNSIGNED NOT NULL, PRIMARY KEY(hotel_id,facility_id),
 FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE, FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE rooms (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hotel_id INT UNSIGNED NOT NULL, name VARCHAR(160) NOT NULL, slug VARCHAR(180) NOT NULL,
 description TEXT, bed_type VARCHAR(100), max_guests TINYINT UNSIGNED DEFAULT 2, room_size INT UNSIGNED, total_quantity INT UNSIGNED DEFAULT 1,
 price_per_night DECIMAL(10,2) NOT NULL, status ENUM('active','inactive') DEFAULT 'active',
 FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE, UNIQUE KEY hotel_room_slug(hotel_id,slug)
) ENGINE=InnoDB;
CREATE TABLE room_images (id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, room_id INT UNSIGNED NOT NULL, image VARCHAR(255) NOT NULL,
 FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE room_facilities (room_id INT UNSIGNED NOT NULL, facility_id INT UNSIGNED NOT NULL, PRIMARY KEY(room_id,facility_id),
 FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE, FOREIGN KEY (facility_id) REFERENCES facilities(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE bookings (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, booking_reference VARCHAR(30) NOT NULL UNIQUE, user_id INT UNSIGNED NULL, hotel_id INT UNSIGNED NOT NULL,
 full_name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL, phone VARCHAR(30) NOT NULL, checkin DATE NOT NULL, checkout DATE NOT NULL,
 adults TINYINT UNSIGNED NOT NULL, children TINYINT UNSIGNED DEFAULT 0, rooms_count TINYINT UNSIGNED NOT NULL,
 subtotal DECIMAL(10,2) NOT NULL, tax DECIMAL(10,2) DEFAULT 0, total_amount DECIMAL(10,2) NOT NULL, status ENUM('Pending','Confirmed','Checked In','Checked Out','Cancelled','Completed') DEFAULT 'Pending',
 payment_status ENUM('Unpaid','Pending','Paid','Failed','Refunded') DEFAULT 'Unpaid', special_requests TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL, FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE RESTRICT,
 INDEX idx_dates(hotel_id,checkin,checkout), INDEX idx_status(status)
) ENGINE=InnoDB;
CREATE TABLE booking_rooms (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, room_id INT UNSIGNED NOT NULL, quantity TINYINT UNSIGNED NOT NULL,
 price_per_night DECIMAL(10,2) NOT NULL,
 FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE, FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE RESTRICT
) ENGINE=InnoDB;
CREATE TABLE payments (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, booking_id INT UNSIGNED NOT NULL, method VARCHAR(50) NOT NULL, transaction_reference VARCHAR(120),
 receipt VARCHAR(255), amount DECIMAL(10,2) NOT NULL, status ENUM('Unpaid','Pending','Paid','Failed','Refunded') DEFAULT 'Unpaid',
 FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE reviews (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, hotel_id INT UNSIGNED NOT NULL, user_id INT UNSIGNED NOT NULL, booking_id INT UNSIGNED NOT NULL,
 rating TINYINT UNSIGNED NOT NULL, comment TEXT, status ENUM('pending','approved','rejected') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE, FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
 FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE wishlists (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, user_id INT UNSIGNED NOT NULL, hotel_id INT UNSIGNED NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY(user_id,hotel_id), FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE
) ENGINE=InnoDB;
CREATE TABLE offers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, title VARCHAR(160) NOT NULL, description TEXT, discount_percent TINYINT UNSIGNED,
 image VARCHAR(255), valid_until DATE, is_active TINYINT(1) DEFAULT 1
) ENGINE=InnoDB;
CREATE TABLE offer_hotels (offer_id INT UNSIGNED NOT NULL, hotel_id INT UNSIGNED NOT NULL, PRIMARY KEY(offer_id,hotel_id),
 FOREIGN KEY (offer_id) REFERENCES offers(id) ON DELETE CASCADE, FOREIGN KEY (hotel_id) REFERENCES hotels(id) ON DELETE CASCADE) ENGINE=InnoDB;
CREATE TABLE contact_messages (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(190) NOT NULL, subject VARCHAR(160),
 message TEXT NOT NULL, status ENUM('new','read','resolved') DEFAULT 'new', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE newsletter_subscribers (
 id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, email VARCHAR(190) NOT NULL UNIQUE, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
CREATE TABLE settings (
 id TINYINT UNSIGNED PRIMARY KEY DEFAULT 1, website_name VARCHAR(160), logo VARCHAR(255), contact_email VARCHAR(190),
 phone VARCHAR(30), address VARCHAR(255), currency VARCHAR(10) DEFAULT 'USD', tax_percent DECIMAL(5,2) DEFAULT 12.00,
 cancellation_policy TEXT
) ENGINE=InnoDB;

INSERT INTO destinations (name,country,image) VALUES
 ('Dhaka','Bangladesh','assets/images/destinations/dhaka.webp'),('Cox''s Bazar','Bangladesh','assets/images/destinations/cox-bazar.webp'),
 ('Sylhet','Bangladesh','assets/images/destinations/sylhet.webp'),('Chattogram','Bangladesh','assets/images/destinations/chittagong.webp'),
 ('Khulna','Bangladesh','assets/images/destinations/khulna.webp');
INSERT INTO facilities (name,icon) VALUES ('Free Wi-Fi','bi-wifi'),('Swimming Pool','bi-water'),('Spa','bi-stars'),('Fitness Center','bi-heart-pulse'),
 ('Restaurant','bi-cup-hot'),('Airport Shuttle','bi-airplane'),('Parking','bi-p-square'),('Room Service','bi-bell');
INSERT INTO users(full_name,email,phone,password_hash,role,is_active) VALUES
 ('Aurelia Administrator','admin@aurelia.test','+8801700000000','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin',1),
 ('Samantha Rahman','samantha@example.com','+8801711111111','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','customer',1);
INSERT INTO admins(user_id,force_password_change) VALUES(1,1);

INSERT INTO hotels(destination_id,name,slug,address,description,star_rating,featured,cancellation_policy) VALUES
(1,'The Grand Aurelia','the-grand-aurelia','Gulshan Avenue, Dhaka','A refined city sanctuary blending modern design with gracious service.',5,1,'Free cancellation up to 48 hours before arrival.'),
(1,'Lakeview Heritage Hotel','lakeview-heritage','Dhanmondi, Dhaka','Elegant rooms and warm hospitality beside the historic heart of Dhaka.',4,1,'Free cancellation up to 24 hours before arrival.'),
(2,'Cox''s Bay Resort','coxs-bay-resort','Marine Drive, Cox''s Bazar','An oceanfront retreat steps from the world''s longest natural beach.',5,1,'Free cancellation up to 72 hours before arrival.'),
(2,'Sapphire Seaside','sapphire-seaside','Kolatoli Road, Cox''s Bazar','Bright coastal rooms with panoramic sea views and relaxed dining.',4,0,'Free cancellation up to 48 hours before arrival.'),
(3,'Sylhet Garden Hotel','sylhet-garden-hotel','Airport Road, Sylhet','Peaceful garden surroundings and effortless access to the city.',4,1,'Free cancellation up to 24 hours before arrival.'),
(3,'Tea Valley Retreat','tea-valley-retreat','Tea Garden Road, Sylhet','A tranquil hillside escape inspired by the region''s tea country.',5,0,'Free cancellation up to 48 hours before arrival.'),
(4,'Harbor View Suites','harbor-view-suites','GEC Circle, Chattogram','Contemporary suites with commanding city and harbor views.',5,1,'Free cancellation up to 48 hours before arrival.'),
(4,'The Meridian Chattogram','the-meridian-chattogram','Nasirabad, Chattogram','A stylish urban hotel for business and leisure travelers.',4,0,'Free cancellation up to 24 hours before arrival.'),
(5,'Mangrove Palace','mangrove-palace','Royal Road, Khulna','Comfortable upscale accommodation near the gateway to the Sundarbans.',4,1,'Free cancellation up to 24 hours before arrival.'),
(5,'Riverside Khulna','riverside-khulna','Rupsha, Khulna','A serene riverside hotel with spacious rooms and local cuisine.',3,0,'Free cancellation up to 24 hours before arrival.');

INSERT INTO hotel_images(hotel_id,image) SELECT id,CONCAT('assets/images/hotels/hotel-',LPAD(id,2,'0'),'.webp') FROM hotels;
INSERT INTO rooms(hotel_id,name,slug,description,bed_type,max_guests,room_size,total_quantity,price_per_night,status) VALUES
(1,'Deluxe King','deluxe-king','Spacious room with a king bed and city views.','1 King Bed',2,34,8,180,'active'),
(1,'Executive Suite','executive-suite','Separate living area and premium amenities.','1 King Bed',3,58,4,310,'active'),
(1,'Family Room','family-room','Comfortable accommodation for the whole family.','2 Queen Beds',5,64,3,260,'active');
INSERT INTO rooms(hotel_id,name,slug,description,bed_type,max_guests,room_size,total_quantity,price_per_night,status)
SELECT hotels.id,r.room_name,LOWER(REPLACE(r.room_name,' ','-')),r.description,r.bed,r.max_guests,r.room_size,r.quantity,r.price,'active'
FROM hotels CROSS JOIN (
 SELECT 'Deluxe Room' room_name,'Elegant room with contemporary furnishings.' description,'1 King Bed' bed,2 max_guests,32 room_size,6 quantity,145.00 price UNION ALL
 SELECT 'Premium Suite','A generous suite with lounge seating.','1 King Bed',3,52,4,245.00 UNION ALL
 SELECT 'Family Suite','Family-friendly space with flexible sleeping.','2 Queen Beds',5,60,3,220.00
) r WHERE id>1;
INSERT INTO room_images(room_id,image) SELECT id,CONCAT('assets/images/hotels/hotel-',LPAD(MOD(id-1,12)+1,2,'0'),'.webp') FROM rooms;
INSERT INTO hotel_facilities SELECT id,1 FROM hotels; INSERT INTO hotel_facilities SELECT id,2 FROM hotels WHERE MOD(id,2)=1;
INSERT INTO hotel_facilities SELECT id,5 FROM hotels WHERE MOD(id,3)!=0; INSERT INTO hotel_facilities SELECT id,8 FROM hotels;
INSERT INTO offers(title,description,discount_percent,image,valid_until) VALUES
('Summer Escape','Enjoy a limited-time seasonal escape with exclusive savings.',20,'assets/images/offers/summer.webp','2027-12-31'),
('Long Stay Reward','Stay longer and enjoy more value across participating hotels.',15,'assets/images/offers/longstay.webp','2027-12-31');
INSERT INTO settings(id,website_name,contact_email,phone,address,currency,tax_percent,cancellation_policy)
VALUES(1,'Aurelia Hotels','reservations@aurelia-hotels.com','+8801700000000','Gulshan, Dhaka','USD',12.00,'Free cancellation is subject to the policy shown with each hotel.');
