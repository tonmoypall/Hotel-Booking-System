<?php
$pageTitle='Booking confirmed | Aurelia';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/navbar.php';
$pdo=getDB();$ref=trim($_GET['ref']??'');$stmt=$pdo->prepare("SELECT b.*,h.name hotel_name,r.name room_name FROM bookings b JOIN hotels h ON h.id=b.hotel_id LEFT JOIN booking_rooms br ON br.booking_id=b.id LEFT JOIN rooms r ON r.id=br.room_id WHERE b.booking_reference=?");$stmt->execute([$ref]);$b=$stmt->fetch();
?>
<main class="section"><div class="container" style="max-width760px"><div class="form-card text-center"><div style="font-size:54px;color:#198754"><i class="bi bi-check-circle-fill"></i></div><p class="eyebrow">BOOKING RECEIVED</p><h1>Your stay is reserved</h1><?php if($b):?><p>Reference <strong><?= e($b['booking_reference']) ?></strong></p><hr><div class="text-start"><p><strong>Hotel:</strong> <?= e($b['hotel_name']) ?></p><p><strong>Room:</strong> <?= e($b['room_name']) ?></p><p><strong>Dates:</strong> <?= e($b['checkin']) ?> to <?= e($b['checkout']) ?></p><p><strong>Total:</strong> <?= money($b['total_amount']) ?></p><p><strong>Status:</strong> <?= e($b['status']) ?></p></div><?php else:?><p>This booking could not be found.</p><?php endif;?></div></div></main>
<?php require_once __DIR__.'/includes/footer.php';?><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script></body></html>
