<?php require_once __DIR__.'/config/config.php'; header('Location: '.BASE_URL.'/hotels.php?'.http_build_query($_GET));exit;
