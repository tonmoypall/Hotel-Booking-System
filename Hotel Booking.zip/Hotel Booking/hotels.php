<?php
$pageTitle='Hotels | Aurelia';
require_once __DIR__.'/includes/header.php';
require_once __DIR__.'/includes/navbar.php';
$pdo=getDB();
$destination=trim($_GET['destination']??'');
$sort=$_GET['sort']??'rating';
$params=[];$where=["h.status='active'"];
if($destination){$where[]='(d.name LIKE :destination_name OR h.address LIKE :destination_address)';$params['destination_name']='%'.$destination.'%';$params['destination_address']='%'.$destination.'%';}
if(!empty($_GET['max_price'])){$where[]='EXISTS (SELECT 1 FROM rooms r0 WHERE r0.hotel_id=h.id AND r0.price_per_night<=:max)';$params['max']=(float)$_GET['max_price'];}
if(!empty($_GET['stars'])){$where[]='h.star_rating=:stars';$params['stars']=(int)$_GET['stars'];}
$order=$sort==='price_low'?'price ASC':($sort==='price_high'?'price DESC':'h.star_rating DESC');
$sql="SELECT h.*,d.name destination,d.country,(SELECT image FROM hotel_images WHERE hotel_id=h.id LIMIT 1) image,(SELECT MIN(price_per_night) FROM rooms WHERE hotel_id=h.id AND status='active') price,(SELECT ROUND(AVG(rating),1) FROM reviews WHERE hotel_id=h.id AND status='approved') rating FROM hotels h JOIN destinations d ON d.id=h.destination_id WHERE ".implode(' AND ',$where)." ORDER BY $order";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$hotels=$stmt->fetchAll();
?>
<section class="page-header"><div class="container"><p class="eyebrow">AURELIA COLLECTION</p><h1>Find your stay</h1></div></section>
<main class="section"><div class="container"><div class="row g-4"><aside class="col-lg-3"><form class="filters-panel" method="get">
<h4>Filter hotels</h4><label class="form-label mt-3">Destination</label><input class="form-control" name="destination" value="<?= e($destination) ?>" placeholder="City or hotel">
<label class="form-label mt-3">Maximum price</label><input class="form-range" type="range" name="max_price" min="100" max="400" value="<?= e($_GET['max_price']??400) ?>" oninput="this.nextElementSibling.value=this.value"><output><?= e($_GET['max_price']??400) ?></output>
<label class="form-label mt-3">Star rating</label><select class="form-select" name="stars"><option value="">Any rating</option><?php for($i=5;$i>=3;$i--):?><option <?= ($_GET['stars']??'')==$i?'selected':'' ?>><?= $i ?></option><?php endfor;?></select>
<label class="form-label mt-3">Sort by</label><select class="form-select" name="sort"><option value="rating" <?= $sort==='rating'?'selected':'' ?>>Rating</option><option value="price_low" <?= $sort==='price_low'?'selected':'' ?>>Price: Low to high</option><option value="price_high" <?= $sort==='price_high'?'selected':'' ?>>Price: High to low</option></select>
<button class="btn btn-gold w-100 mt-3">Apply filters</button></form></aside><div class="col-lg-9"><p class="mb-3"><strong><?= count($hotels) ?></strong> hotels found</p>
<?php foreach($hotels as $h): ?><article class="listing-card"><img src="<?= e(BASE_URL.'/'.$h['image']) ?>" alt="<?= e($h['name']) ?>" loading="lazy"><div class="listing-content"><p class="location"><i class="bi bi-geo-alt"></i> <?= e($h['destination'].', '.$h['country']) ?></p><h3><?= e($h['name']) ?></h3><div class="stars"><?= str_repeat('<i class="bi bi-star-fill"></i>',(int)$h['star_rating']) ?></div><p><?= e(substr(strip_tags($h['description']),0,155)) ?>...</p><div class="hotel-card-foot"><div><small>From</small><strong><?= money($h['price']) ?></strong><small>/ night</small></div><a class="btn btn-outline-navy" href="<?= e(BASE_URL) ?>/hotel-details.php?slug=<?= urlencode($h['slug']) ?>">View hotel</a></div></div></article><?php endforeach; ?>
</div></div></div></main>
<?php require_once __DIR__.'/includes/footer.php'; ?><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script><script src="<?= e(BASE_URL) ?>/assets/js/main.js"></script></body></html>
