# Aurelia Hotels

A database-driven PHP/MySQL hotel booking and management system for XAMPP.

## Features
- Public hotel search and filtering
- Hotel and room details
- User registration and login
- Customer dashboard and bookings
- Availability-checked reservations
- Cash at Hotel and manual bank transfer payment workflows
- Admin hotel, room, booking, customer, payment and review management
- Local images and Bootstrap-based responsive interface

## Run locally
1. Start Apache and MySQL in XAMPP.
2. Import `database/schema.sql` in phpMyAdmin.
3. Open `http://localhost/Hotel%20Booking/`.

Default admin credentials: `admin@aurelia.test` / `password`
