<?php
$active = basename($_SERVER['PHP_SELF']);
?>
<header class="navbar-shell">
  <nav class="navbar navbar-expand-lg container">
    <a class="navbar-brand brand" href="<?= e(BASE_URL) ?>/"><span class="brand-mark">A</span><span>Aurelia</span></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav mx-auto">
        <li class="nav-item"><a class="nav-link <?= $active==='index.php'?'active':'' ?>" href="<?= e(BASE_URL) ?>/">Home</a></li>
        <li class="nav-item"><a class="nav-link <?= $active==='hotels.php'?'active':'' ?>" href="<?= e(BASE_URL) ?>/hotels.php">Hotels</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>/hotels.php#destinations">Destinations</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>/about.php">About</a></li>
        <li class="nav-item"><a class="nav-link" href="<?= e(BASE_URL) ?>/contact.php">Contact</a></li>
      </ul>
      <div class="nav-actions">
        <?php if (is_logged_in()): ?>
          <a class="nav-link d-inline-block" href="<?= e(BASE_URL) ?>/dashboard/">My Bookings</a>
          <a class="btn btn-sm btn-outline-light ms-2" href="<?= e(BASE_URL) ?>/logout.php">Logout</a>
        <?php else: ?>
          <a class="nav-link d-inline-block" href="<?= e(BASE_URL) ?>/login.php">Login</a>
          <a class="btn btn-gold btn-sm ms-2" href="<?= e(BASE_URL) ?>/register.php">Register</a>
        <?php endif; ?>
      </div>
    </div>
  </nav>
</header>
