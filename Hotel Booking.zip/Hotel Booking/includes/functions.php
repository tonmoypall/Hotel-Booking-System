<?php
declare(strict_types=1);

function e(string|null $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): bool {
    return isset($_POST['csrf_token'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf_token']);
}

function redirect(string $path): never {
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

function is_logged_in(): bool {
    return isset($_SESSION['user_id']);
}

function is_admin(): bool {
    return ($_SESSION['role'] ?? '') === 'admin';
}

function require_login(): void {
    if (!is_logged_in()) redirect('login.php');
}

function require_admin(): void {
    if (!is_admin()) redirect('login.php');
}

function json_response(array $data, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function money($amount): string {
    return '$' . number_format((float)$amount, 2);
}

function nights(string $checkin, string $checkout): int {
    $diff = (new DateTimeImmutable($checkout))->diff(new DateTimeImmutable($checkin));
    return (int)$diff->format('%r%a');
}
