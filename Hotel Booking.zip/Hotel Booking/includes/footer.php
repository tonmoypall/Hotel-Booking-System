<footer class="site-footer">
  <div class="container">
    <div class="row g-4">
      <div class="col-lg-4">
        <a class="navbar-brand brand text-white" href="<?= e(BASE_URL) ?>/"><span class="brand-mark">A</span><span>Aurelia</span></a>
        <p class="mt-3">Exceptional stays, thoughtfully selected and beautifully delivered around the world.</p>
      </div>
      <div class="col-6 col-lg-2"><h6>Explore</h6><a href="<?= e(BASE_URL) ?>/hotels.php">Hotels</a><a href="<?= e(BASE_URL) ?>/about.php">About us</a><a href="<?= e(BASE_URL) ?>/contact.php">Contact</a></div>
      <div class="col-6 col-lg-3"><h6>Support</h6><a href="#">Privacy Policy</a><a href="#">Terms & Conditions</a><a href="#">Cancellation Policy</a></div>
      <div class="col-lg-3"><h6>Stay in touch</h6><p>reservations@aurelia-hotels.com<br>+880 1700 000000</p></div>
    </div>
    <div class="footer-bottom">© <?= date('Y') ?> Aurelia Hotels. All rights reserved.</div>
  </div>
</footer>
